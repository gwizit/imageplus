# ImagePlus Installation & Upgrade Guide

## What is ImagePlus?

ImagePlus is an enhanced version of the "Image Replacer" plugin that allows Moodle administrators to search and replace not only images but also other file types (PDFs, documents, videos, audio, archives) across their entire Moodle installation based on filename patterns.

**Key Features:**
- ✨ **Multi-File Support**: Images, PDFs, ZIPs, Documents, Videos, Audio
- 🔍 **Smart Search**: Find files by filename pattern across database and filesystem
- 🎨 **Image Processing**: Auto-resize and convert images to match target formats
- 📋 **File Copy**: Direct replacement for non-image files
- 🔒 **Safe Preview**: Test replacements without making changes
- 📊 **Detailed Logging**: Track all operations

---

## Installation (New Installation)

### Method 1: Via Moodle Plugin Installer

1. **Create a ZIP file** of the `imageplus` folder
2. Log in to Moodle as administrator
3. Navigate to: **Site administration → Plugins → Install plugins**
4. Upload the ZIP file
5. If prompted, select **"Local plugin (local)"** as plugin type
6. Confirm folder name is **"imageplus"**
7. Click "Install plugin from the ZIP file"
8. Follow on-screen instructions

### Method 2: Manual Installation

1. Copy the `imageplus` folder to `[moodle-root]/local/`
2. Log in to Moodle as administrator
3. Navigate to: **Site administration → Notifications**
4. Click **"Upgrade Moodle database now"**
5. Follow on-screen instructions

### Method 3: Command Line

```bash
cd [moodle-root]/local/
cp -r /path/to/imageplus .
cd [moodle-root]
php admin/cli/upgrade.php
```

---

## Upgrading from Image Replacer

If you have the old "Image Replacer" plugin installed, you have two options:

### Option A: Fresh Install (Recommended)

1. **Backup your Moodle database** (especially the `local_imagereplacer_log` table if you want to keep logs)
2. Uninstall the old "Image Replacer" plugin:
   - Go to **Site administration → Plugins → Local plugins → Image Replacer**
   - Click "Uninstall"
   - Follow prompts
3. Install ImagePlus using one of the methods above

### Option B: In-Place Upgrade (Advanced)

**Warning**: This requires manual database changes. Backup first!

1. **Backup your entire Moodle database**
2. Stop your web server
3. Delete the old plugin folder: `[moodle-root]/local/imagereplacer`
4. Copy the new `imageplus` folder to `[moodle-root]/local/`
5. Manually rename database tables:
   ```sql
   RENAME TABLE mdl_local_imagereplacer_log TO mdl_local_imageplus_log;
   ```
6. Update configuration settings in the database:
   ```sql
   UPDATE mdl_config_plugins SET plugin = 'local_imageplus' WHERE plugin = 'local_imagereplacer';
   ```
7. Update capabilities:
   ```sql
   UPDATE mdl_capabilities SET name = 'local/imageplus:manage' WHERE name = 'local/imagereplacer:manage';
   UPDATE mdl_capabilities SET name = 'local/imageplus:view' WHERE name = 'local/imagereplacer:view';
   UPDATE mdl_role_capabilities SET capability = 'local/imageplus:manage' WHERE capability = 'local/imagereplacer:manage';
   UPDATE mdl_role_capabilities SET capability = 'local/imageplus:view' WHERE capability = 'local/imagereplacer:view';
   ```
8. Clear Moodle caches:
   ```bash
   php admin/cli/purge_caches.php
   ```
9. Start your web server
10. Navigate to: **Site administration → Notifications**
11. Complete the upgrade

---

## Configuration

After installation:

1. Go to: **Site administration → Plugins → Local plugins → ImagePlus**
2. Configure default settings:
   - **Default search term**: Pre-fill the search box
   - **Default execution mode**: Preview (recommended) or Execute
   - **Preserve permissions by default**: Keep file permissions
   - **Search database by default**: Include Moodle file storage
   - **Search file system by default**: Include filesystem directories

---

## Usage

### Accessing the Tool

1. Log in as site administrator or manager
2. Navigate to: **Site administration → Server → ImagePlus**

### Replacing Files

1. **Enter Search Term**: Filename pattern to search for (e.g., "logo", "2024", "banner")
2. **Select File Type**: Choose which type of files to search for
3. **Upload Replacement File**: Select the file to use as replacement
4. **Choose Execution Mode**:
   - **Preview**: See what would change (recommended first)
   - **Execute**: Actually perform replacements
5. **Select Options**:
   - ☑️ Preserve file permissions
   - ☑️ Include database files
   - ☑️ Include file system
6. Click **"Find matching files"** (preview) or **"Replace files"** (execute)

### File Type Options

- **All file types**: Searches for any file
- **Images only**: JPG, JPEG, PNG, WebP (with auto-resize/convert)
- **PDF documents**: PDF files only
- **Archives**: ZIP, TAR, GZ, RAR, 7Z
- **Documents**: DOC, DOCX, ODT, TXT, RTF
- **Videos**: MP4, AVI, MOV, WMV, FLV, WebM
- **Audio**: MP3, WAV, OGG, M4A, FLAC

---

## Important Notes

### Image Files
When replacing images with images:
- Source image is automatically resized to match each target image dimensions
- Format conversion happens automatically (JPEG ↔ PNG ↔ WebP)
- Transparency is preserved for PNG and WebP

### Non-Image Files
When replacing PDFs, documents, etc.:
- Files are copied directly with no modification
- File permissions are preserved (if option enabled)
- File must be compatible with the original file type

### Permissions Required

Users need one of these capabilities:
- `local/imageplus:manage` - Perform replacements
- `local/imageplus:view` - View the tool (typically assigned to managers)

---

## Troubleshooting

### Plugin doesn't appear in menu
- Clear Moodle caches: **Site administration → Development → Purge all caches**
- Check permissions: User needs `local/imageplus:view` capability

### Can't upload large files
- Increase PHP upload limits in `php.ini`:
  ```ini
  upload_max_filesize = 50M
  post_max_size = 50M
  ```
- Increase Moodle limits: **Site administration → Server → PHP info**

### Replacements not working
- Check file permissions on server
- Enable debugging: **Site administration → Development → Debugging**
- Review operation log for specific errors

### Old plugin name appears
- You may need to completely uninstall old plugin first
- Clear all caches
- Check for remaining `local_imagereplacer` entries in database

---

## System Requirements

- **Moodle**: 5.0 or higher
- **PHP**: 7.4 or higher with GD library (for image processing)
- **PHP Extensions**: GD, FileInfo
- **Disk Space**: Sufficient for temporary file operations
- **Permissions**: Write access to `moodledata/temp` directory

---

## File Structure

```
imageplus/
├── index.php                      # Main interface
├── version.php                    # Plugin version info
├── settings.php                   # Admin settings
├── renderer.php                   # Output rendering
├── classes/
│   ├── replacer.php              # Core replacement logic
│   ├── form/
│   │   └── replacer_form.php     # Search/replace form
│   ├── event/
│   │   └── images_replaced.php   # Event logging
│   └── privacy/
│       └── provider.php          # GDPR compliance
├── db/
│   ├── access.php                # Capabilities
│   └── install.xml               # Database schema
├── lang/
│   └── en/
│       └── local_imageplus.php   # English strings
└── amd/
    └── src/
        └── filepicker_patch.js   # JavaScript enhancements
```

---

## Support

- **Documentation**: See README.md and TROUBLESHOOTING.md
- **Developer**: G Wiz IT Solutions
- **Website**: https://gwizit.com
- **License**: GNU GPL v3 or later

---

## Version History

**v2.0.0** (October 16, 2025)
- Renamed from "Image Replacer" to "ImagePlus"
- Added support for PDF, ZIP, DOC, VIDEO, AUDIO file types
- Added file type selector dropdown
- Enhanced file search with MIME type filtering
- Increased max file size to 50MB
- Updated all language strings
- Improved error messages

**v1.0.5** (October 15, 2025)
- Original Image Replacer version
- Image-only support

---

**Congratulations!** Your ImagePlus plugin is now installed and ready to use.
