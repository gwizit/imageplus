<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Image Replacer main interface
 *
 * @package    local_imageplus
 * @copyright  2025 G Wiz IT Solutions {@link https://gwizit.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @author     G Wiz IT Solutions
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

admin_externalpage_setup('local_imageplus_tool');

require_login();
require_capability('local/imageplus:view', context_system::instance());

$action = optional_param('action', '', PARAM_ALPHA);

$PAGE->set_url(new moodle_url('/local/imageplus/index.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('pluginname', 'local_imageplus'));
$PAGE->set_heading(get_string('heading', 'local_imageplus'));
$PAGE->requires->js_call_amd('local_imageplus/filepicker_patch', 'init');

// Get default settings.
$defaultsearchterm = get_config('local_imageplus', 'defaultsearchterm');
$defaultmode = get_config('local_imageplus', 'defaultmode');
$defaultpreservepermissions = get_config('local_imageplus', 'defaultpreservepermissions');
$defaultsearchdatabase = get_config('local_imageplus', 'defaultsearchdatabase');
$defaultsearchfilesystem = get_config('local_imageplus', 'defaultsearchfilesystem');

// Handle form submission.
if ($action === 'search' || $action === 'replace' || $action === 'confirm') {
    require_capability('local/imageplus:manage', context_system::instance());
    require_sesskey();

    $searchterm = required_param('searchterm', PARAM_TEXT);
    $executionmode = optional_param('executionmode', 'preview', PARAM_ALPHA);
    $filetype = optional_param('filetype', 'image', PARAM_ALPHA);
    $preservepermissions = optional_param('preservepermissions', 0, PARAM_INT);
    $searchdatabase = optional_param('searchdatabase', 0, PARAM_INT);
    $searchfilesystem = optional_param('searchfilesystem', 0, PARAM_INT);
    $allowimageconversion = optional_param('allowimageconversion', 1, PARAM_INT);

    // For 'confirm' action, get selected files
    $selectedfilesystemfiles = optional_param_array('filesystem_files', [], PARAM_TEXT);
    $selecteddatabasefiles = optional_param_array('database_files', [], PARAM_INT);

    // Handle file upload from filemanager.
    $draftitemid = optional_param('draftitemid', 0, PARAM_INT);
    if ($action !== 'confirm') {
        $draftitemid = file_get_submitted_draft_itemid('sourceimage');
    }
    
    $fs = get_file_storage();
    $usercontext = context_user::instance($USER->id);
    $files = $fs->get_area_files($usercontext->id, 'user', 'draft', $draftitemid, 'id DESC', false);
    
    if (empty($files)) {
        redirect($PAGE->url, get_string('error_nosourcefile', 'local_imageplus'), 
            null, \core\output\notification::NOTIFY_ERROR);
    }

    $file = reset($files);
    
    // For image file types, validate it's actually an image
    if ($filetype === 'image' && !in_array($file->get_mimetype(), ['image/jpeg', 'image/png', 'image/webp'])) {
        redirect($PAGE->url, get_string('error_invalidfiletype', 'local_imageplus'), 
            null, \core\output\notification::NOTIFY_ERROR);
    }

    // Check if GD is required but not available
    if ($filetype === 'image' && !in_array($file->get_mimetype(), ['image/jpeg', 'image/png', 'image/webp'])) {
        if (!\local_imageplus\replacer::is_gd_available()) {
            redirect($PAGE->url, get_string('error_nogd_required', 'local_imageplus'),
                null, \core\output\notification::NOTIFY_ERROR);
        }
    }
    
    // Copy file to temp directory.
    $tempfile = make_temp_directory('imagereplacer') . '/' . clean_filename($file->get_filename());
    $file->copy_content_to($tempfile);

    // Create replacer instance.
    $config = [
        'search_term' => $searchterm,
        'dry_run' => ($executionmode === 'preview'),
        'preserve_permissions' => (bool)$preservepermissions,
        'search_database' => (bool)$searchdatabase,
        'search_filesystem' => (bool)$searchfilesystem,
        'file_type' => $filetype,
        'allow_image_conversion' => (bool)$allowimageconversion,
    ];

    $replacer = new \local_imageplus\replacer($config);

    if (!$replacer->load_source_file($tempfile)) {
        @unlink($tempfile);
        redirect($PAGE->url, get_string('error_invalidfile', 'local_imageplus'),
            null, \core\output\notification::NOTIFY_ERROR);
    }

    // Find files.
    $filesystemfiles = $replacer->find_filesystem_files();
    $databasefiles = $replacer->find_database_files();

    // Determine which files to process
    $filesToProcess = $filesystemfiles;
    $dbFilesToProcess = $databasefiles;
    
    if ($action === 'confirm') {
        // Filter to only selected files
        $filesToProcess = array_values(array_intersect($filesystemfiles, $selectedfilesystemfiles));
        
        // Filter database files by selected IDs
        $dbFilesToProcess = array_filter($databasefiles, function($file) use ($selecteddatabasefiles) {
            return in_array($file->id, $selecteddatabasefiles);
        });
        $dbFilesToProcess = array_values($dbFilesToProcess);
    }

    if ($action === 'replace' || $action === 'confirm') {
        // Process files.
        $replacer->process_filesystem_files($filesToProcess);
        $replacer->process_database_files($dbFilesToProcess);

        // Log operation.
        $replacer->log_operation($USER->id);

        // Trigger event.
        $event = \local_imageplus\event\images_replaced::create([
            'context' => context_system::instance(),
            'other' => [
                'searchterm' => $searchterm,
                'filesreplaced' => $replacer->get_stats()['files_replaced'],
                'dbfilesreplaced' => $replacer->get_stats()['db_files_replaced'],
            ],
        ]);
        $event->trigger();
    }

    // Clean up temp file.
    @unlink($tempfile);

    // Display results.
    echo $OUTPUT->header();

    $renderer = $PAGE->get_renderer('local_imageplus');
    
    // Prepare form data for confirmation form
    $formdata = [
        'searchterm' => $searchterm,
        'filetype' => $filetype,
        'allowimageconversion' => $allowimageconversion,
        'preservepermissions' => $preservepermissions,
        'draftitemid' => $draftitemid,
    ];
    
    echo $renderer->render_results($replacer, $filesystemfiles, $databasefiles, $action === 'search', $formdata);

    echo $OUTPUT->footer();
    exit;
}

// Display form.
echo $OUTPUT->header();

echo $OUTPUT->heading(get_string('heading', 'local_imageplus'));
echo html_writer::tag('p', get_string('description', 'local_imageplus'));

// Check GD library availability and display warning if missing
if (!\local_imageplus\replacer::is_gd_available()) {
    echo $OUTPUT->notification(get_string('warning_nogd_detailed', 'local_imageplus'), 
        \core\output\notification::NOTIFY_WARNING);
}

// Credits.
echo html_writer::tag('p', get_string('credits', 'local_imageplus'), ['class' => 'alert alert-info']);

// Build form.
$formdata = new stdClass();
$formdata->searchterm = $defaultsearchterm;
$formdata->executionmode = $defaultmode ? 'preview' : 'execute';
$formdata->preservepermissions = $defaultpreservepermissions;
$formdata->searchdatabase = $defaultsearchdatabase;
$formdata->searchfilesystem = $defaultsearchfilesystem;

// Prepare filemanager for source image upload.
$draftitemid = 0;
file_prepare_draft_area($draftitemid, context_system::instance()->id, 'local_imageplus', 'sourceimage', 0,
    ['subdirs' => 0, 'maxbytes' => 10485760, 'maxfiles' => 1]);
$formdata->sourceimage = $draftitemid;

$mform = new \local_imageplus\form\replacer_form(null, ['formdata' => $formdata]);

$mform->display();

// Display directories info.
echo html_writer::start_div('alert alert-info mt-3');
echo html_writer::tag('strong', get_string('directoriesscanned', 'local_imageplus'));
echo html_writer::tag('p', get_string('directories_list', 'local_imageplus'));
echo html_writer::end_div();

echo $OUTPUT->footer();
